package tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.junit.Assert.assertEquals;

public class fluxoprincipalTest {
    private WebDriver navegador; //Utilizando para todos os metodos
    private WebElement caixadepesquisa;
    private WebDriverWait aguardar;
    private WebElement retono;

    @Before
    public void precondicao(){
        System.setProperty("webdriver.chrome.driver", "/Users/matheusluis/drivers/chromedriver");
        navegador = new ChromeDriver();
        //navegador.manage().window().fullscreen();
        navegador.get("https://www.amazon.com.br/");
    }

    @Test
    public void testValidarProdutonoCarrinho() {
        caixadepesquisa = navegador.findElement(By.id("twotabsearchtextbox"));
        caixadepesquisa.click();
        caixadepesquisa.sendKeys("O Senhor dos Anéis: As duas torres");
        navegador.findElement(By.className("nav-input")).click();
        //Validar Retorno da Busca com Assert
        WebElement retornodabusca = navegador.findElement(By.linkText("O Senhor dos Anéis: As duas torres"));
        String retorno = retornodabusca.getText();
        assertEquals("O Senhor dos Anéis: As duas torres", retorno);
        //Screenshot.tirar(navegador, "Diretorio");
        //Escolhendo o Produto
        navegador.findElement(By.partialLinkText("O Senhor dos Anéis: As duas torres")).click();
        //Adiconado ao Carrinho
        navegador.findElement(By.id("add-to-cart-button")).click();
        //Validar Produto no Carrinho
        WebElement retornodocarrinho = navegador.findElement(By.id("huc-v2-confirm-text-container"));
        String carrinho = retornodocarrinho.getText();
        assertEquals("Adicionado ao carrinho", carrinho);
        //Screenshot.tirar(navegador, "Diretorio");


    }
    @After
    public void poscondicao() {

        //navegador.close();

    }
}