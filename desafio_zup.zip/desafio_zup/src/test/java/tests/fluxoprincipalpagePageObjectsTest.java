package tests;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import pages.BuscarProdutoPage;
import suporte.Web;

public class fluxoprincipalpagePageObjectsTest {
    private WebDriver navegador;

    @Before
    public void precondicao(){
        navegador = Web.createChrome();
    }

    @Test
        public void testValidarProdutonoCarrinho(){
        new BuscarProdutoPage(navegador)
                    .digitarproduto("O Senhor dos Anéis: As duas torres")
                    .escolheroproduto()
                    .adicionaraoCarrinho();
        }

    @After
    public void poscondicao(){
        navegador.close();
    }

}
