package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class escolherProdutoPage {
    private WebDriver navegador;

    public escolherProdutoPage(WebDriver navegador){
        this.navegador = navegador;
    }

    public addCarrinhoPage escolheroproduto(){
        navegador.findElement(By.linkText("O Senhor dos Anéis: As duas torres")).click();;
        return new addCarrinhoPage(navegador);
    }

}
