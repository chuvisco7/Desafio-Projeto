package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class addCarrinhoPage {

    private WebDriver navegador;

    public addCarrinhoPage(WebDriver navegador){
        this.navegador = navegador;

    }

    public addCarrinhoPage adicionaraoCarrinho(){
        navegador.findElement(By.id("add-to-cart-button")).click();
        return this;
    }
}
