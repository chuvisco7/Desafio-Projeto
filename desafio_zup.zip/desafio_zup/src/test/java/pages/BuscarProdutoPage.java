package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BuscarProdutoPage {

    private WebDriver navegador;

    public BuscarProdutoPage(WebDriver navegador){
        this.navegador = navegador;
    }


 public escolherProdutoPage digitarproduto(String s) {
     navegador.findElement(By.id("twotabsearchtextbox")).click();
     navegador.findElement(By.id("twotabsearchtextbox")).sendKeys("O Senhor dos Anéis: As duas torres");
     navegador.findElement(By.className("nav-input")).click();
     return new escolherProdutoPage(navegador);
 }


}
