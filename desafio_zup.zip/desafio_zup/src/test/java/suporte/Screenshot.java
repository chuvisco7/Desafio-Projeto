package suporte;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import sun.reflect.misc.FieldUtil;


import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;

import java.io.File;

public class Screenshot {
    public static void tirar (WebElement navegador, String arquivo){
        File screenshot = ((TakesScreenshot)navegador).getScreenshotAs(OutputType.FILE);
        try{
           FileUtils.copyFile(screenshot, new File(arquivo));
        }catch (Exception e){
            System.out.println("Houveram Problemas ao copiar arquivo para o diretorio" +e.getMessage());
        }

    }


}
