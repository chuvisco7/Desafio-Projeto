package suporte;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Web {
    private WebElement caixadepesquisa;



    public static WebDriver createChrome (){//metodo
        System.setProperty("webdriver.chrome.driver", "/Users/matheusluis/drivers/chromedriver");
        WebDriver navegador = new ChromeDriver();
        //navegador.manage().window().fullscreen();
        navegador.get("https://www.amazon.com.br/");


        return navegador;
    }
}




